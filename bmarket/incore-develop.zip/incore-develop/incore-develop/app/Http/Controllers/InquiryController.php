<?php

namespace App\Http\Controllers;

class InquiryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

       return view('inquiry.index');
       
    }

}
