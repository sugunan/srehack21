package email.config.property;

public enum EmailProperty {
    POP3,
    IMAP,
    SMTP
}
