package email.config.property;

import java.util.Properties;

public interface PropertyImpl {
    Properties getProperties();
}
