package email.config;

public class EmailAccount {
    public static final String EMAIL_ADDRESS = "hashandarshana19990809@gmail.com";
    public static final String EMAIL_PASSWORD = "NewPassword1999";
}
