package email.config.property;

public class PropertyFactory {
    public static PropertyImpl getConfig(EmailProperty configType) {
        switch (configType) {
            case POP3:
                return new POP3Properties();
            case IMAP:
                return new IMAPProperties();
            case SMTP:
                return new SMTPProperties();
            default:
                return null;
        }
    }
}
