package functions;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class FirebaseUtil {

    static {
        init();
    }

    private static void init() {

    }

    public static void initializeApp() throws IOException {
        InputStream serviceAccount = null;
        try {
            serviceAccount = new FileInputStream("C:\\Users\\OBITO\\Documents\\NetBeansProjects\\AutomationEmailUI\\firebase.json");
            GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount);
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setCredentials(credentials)
                    .build();
            FirebaseApp.initializeApp(options);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

}
