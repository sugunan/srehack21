package com.example.test1.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class EmailDetails {

    String from;
    String senderName;
    String subject;
    String message;
    Date receivedTime;
    Date completedTime;
    String status;
    String type;
    int issueCount;
    int requestCount;




}
