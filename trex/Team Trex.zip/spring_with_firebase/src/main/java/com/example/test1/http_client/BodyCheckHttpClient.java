package com.example.test1.http_client;

import com.google.gson.JsonObject;
import lombok.SneakyThrows;
import okhttp3.*;
import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONObject;

public class BodyCheckHttpClient {

    @SneakyThrows
    public String check(String text) {
//        OkHttpClient client = new OkHttpClient().newBuilder()
//                .build();
//
//        JsonObject jsonObject = new JsonObject();
//        jsonObject.addProperty("content", text);
//
////        RequestBody requestBody = new RequestBody();
//
//        Request request = new Request.Builder()
//                .url("112.134.220.188/nlpscanner/scan")
//                .method("POST", )
//                .addHeader("Content-Type", "application/json")
//                .addHeader("Authorization", "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI5IiwiaWF0IjoxNjM2MzY4MDk2LCJleHAiOjE2MzY5NzI4OTZ9.USwzP_D_h1kyiN1XHv1onPSL4ZJHobql-0s-5OXbDXtxD6csOBwiBkUpLLa_Nxk59L_ZhBOpjgmkjmT9ZGEJ6A")
//                .build();
//        Response response = client.newCall(request).execute();
//        System.out.println(response.body().string());


        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("content","asa sas as as a")
                .build();
        Request request = new Request.Builder()
                .url("http://192.168.1.26:8080/nlpscanner/scan?content="+text)
                .method("POST", body)
                .build();
        Response response = client.newCall(request).execute();
        System.out.println(response.body().string());

//        JSONParser parser = new JSONParser();
//        JSONObject json = (JSONObject) parser.parse(stringToParse);stringToParse

        return "ok";
    }




}
