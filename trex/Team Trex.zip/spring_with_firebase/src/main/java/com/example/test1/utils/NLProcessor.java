package com.example.test1.utils;

//import edu.stanford.nlp.pipeline.StanfordCoreNLP;

import java.util.Properties;

public class NLProcessor {

//    private static Properties properties;
//    private static String actionName = "tokenize, ssplit, pos, lemma";
//
//    private static StanfordCoreNLP stanfordCoreNLP;
//
//    static {
//        properties = new Properties();
//        properties.setProperty("annotators", actionName);
//    }
//    public static StanfordCoreNLP getActionLine(){
//        if(stanfordCoreNLP==null){
//            stanfordCoreNLP = new StanfordCoreNLP(properties);
//        }
//        return stanfordCoreNLP;
//    }
}
