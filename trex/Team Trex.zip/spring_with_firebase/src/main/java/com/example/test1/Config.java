package com.example.test1;

public class Config {
    public static final String HOST = "smtp.gmail.com";
//    public static final String USER = "trexteam2021hackathon@gmail.com";
//    public static final String PASSWORD = "kmnekqnaagggfqqe";
//
    public static final String USER = "kkddulmin@gmail.com";
    public static final String PASSWORD = "TrexAccount";

    public static final String MAILSTORE = "pop3";

}
