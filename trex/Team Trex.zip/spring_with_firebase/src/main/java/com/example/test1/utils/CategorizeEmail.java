package com.example.test1.utils;

//import edu.stanford.nlp.ling.CoreAnnotations;
//import edu.stanford.nlp.ling.CoreLabel;
//import edu.stanford.nlp.pipeline.CoreDocument;
//import edu.stanford.nlp.pipeline.CoreSentence;
//import edu.stanford.nlp.pipeline.StanfordCoreNLP;

public class CategorizeEmail {

//    public void checkBody(String languageText){
//        StanfordCoreNLP stanfordCoreNLP = NLProcessor.getActionLine();
//
////        String languageText = "Conntent";
//
//        CoreDocument coreDocument = new CoreDocument(languageText);
//        stanfordCoreNLP.annotate(coreDocument);
//        for (
//                CoreSentence sentence : coreDocument.sentences()) {
//            for (CoreLabel word : sentence.tokens()) {
//                String wordSpeechAnnotation = word.get(CoreAnnotations.PartOfSpeechAnnotation.class);
//                if (wordSpeechAnnotation.equals("VB")) {
//                    System.out.print(word.originalText() + "  " + word.lemma() + " " + wordSpeechAnnotation);
//
//                }
//            }
//            System.out.println();
//        }
//    }

}
